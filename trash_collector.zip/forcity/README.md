# Trash Collector

## Quick start:
```
./demo.py tests/good
```

You can edit **test/good** with custom values. 
> **Note:** Keep in mind that wrong or missing values are not supported. 


## unit tests

Unit tests are only present in the **Loading** file. To launch them:
```
chmod -r tests/no_readable
./Loading.py
```
They actually check from the opening file to the JSON loading, not the JSON content.