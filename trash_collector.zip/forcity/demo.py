#!/usr/bin/python

import Loading
import sys
import math
import random

def Move(map):
	"""Move the bot in the clother trash direction.
	"""

	# increase current round (create it if not exist)
	try:
		map["map"]["current_round"] += 1
	except KeyError:
		map["map"]["current_round"] = 1
	
	# found clother trash
	clother_trash = map["trash"][0]
	distance = math.fabs(map["bot"]["x_pos"] - map["trash"][0]["x_pos"]) + math.fabs(map["bot"]["y_pos"] - map["trash"][0]["y_pos"])
	for trash in map["trash"]:
		if math.fabs(map["bot"]["x_pos"] - trash["x_pos"]) + math.fabs(map["bot"]["y_pos"] - trash["y_pos"]) < distance:
			distance = math.fabs(map["bot"]["x_pos"] - trash["x_pos"]) + math.fabs(map["bot"]["y_pos"] - trash["y_pos"])
			clother_trash = trash
	
	# go to trash
	nb_move = map["map"]["max_range"]
	while nb_move != 0 and map["bot"]["x_pos"] != clother_trash["x_pos"]:
		map["bot"]["x_pos"] += 1 if map["bot"]["x_pos"] < clother_trash["x_pos"] else -1
		nb_move -= 1
	while nb_move != 0 and map["bot"]["y_pos"] != clother_trash["y_pos"]:
		map["bot"]["y_pos"] += 1 if map["bot"]["y_pos"] < clother_trash["y_pos"] else -1
		nb_move -= 1

def Clean(map):
	"""Remove trash if the bot is over it.
	"""
	for trash in map["trash"]:
		if trash["x_pos"] == map["bot"]["x_pos"] and trash["y_pos"] == map["bot"]["y_pos"]:
			map["trash"].remove(trash)
			print("Round " + str(map["map"]["current_round"]) + "/" + str(map["map"]["max_rounds"])
				+ " : trash collected, remaining " + str(len(map["trash"])) + ".")
			break
	# old method: (couldn't log)
	# map["trash"] = [trash for trash in map["trash"]
	#	if trash["x_pos"] != map["bot"]["x_pos"] or trash["y_pos"] != map["bot"]["y_pos"]]

def EmptyPos(posX, posY, map):
	if posX <= 0 or posX > map["map"]["x_max"]:
		return 0
	if posY <= 0 or posY > map["map"]["y_max"]:
		return 0
	for trash in map["trash"]:
		if trash["x_pos"] == posX and trash["y_pos"] == posY:
			return 0
	return 1

def Extend(map):
	"""Extrend all trash with a probability of 1/4.
	"""
	new_trash = []
	for trash in map["trash"]:
		if random.randint(1,4) == 4:
			# found an empty pos next to the trash
			if EmptyPos(trash["x_pos"], trash["y_pos"] + 1, map):
				new_trash.append({u'x_pos':trash["x_pos"], u'y_pos':trash["y_pos"] + 1})
			elif EmptyPos(trash["x_pos"], trash["y_pos"] - 1, map):
				new_trash.append({u'x_pos':trash["x_pos"], u'y_pos':trash["y_pos"] - 1})
			elif EmptyPos(trash["x_pos"] + 1, trash["y_pos"], map):
				new_trash.append({u'x_pos':trash["x_pos"] + 1, u'y_pos':trash["y_pos"]})
			elif EmptyPos(trash["x_pos"] - 1, trash["y_pos"], map):
				new_trash.append({u'x_pos':trash["x_pos"] - 1, u'y_pos':trash["y_pos"]})
			else:
				continue
			print("Round " + str(map["map"]["current_round"]) + "/" + str(map["map"]["max_rounds"])
				+ ": trash pop, remaining " + str(len(map["trash"]) + len(new_trash)) + ".")
	map["trash"] += new_trash


def EndCondition(map):
	if map["map"]["current_round"] == map["map"]["max_rounds"] or len(map["trash"]) == 0:
		return 1
	return 0


if __name__ == "__main__":
	if len(sys.argv) != 2:
		print "Usage: ./demo.py file"
	else:
		try:
			map = Loading.Loading(sys.argv[-1])
		except ValueError:
			pass
		else:
			while 1:
				Move(map)
				Clean(map)
				Extend(map)
				if EndCondition(map):
					break
			if len(map["trash"]):
				print("Game over. " + str(len(map["trash"])) + " trash remaining after " + str(map["map"]["current_round"]) + " rounds.")
			else:
				print("Success. Collected all trash in " + str(map["map"]["current_round"]) + " rounds.")

# TODO list:

# make a Map class for all parameters and functions (access of json structure not very clear)
# Add tests in Loading.py (actually crash if missing value or no error if invalid value [ex => x_pos:-1])
# possibility to make graphical version (I found Tkinter module. It's look like easyToUse and fun...)