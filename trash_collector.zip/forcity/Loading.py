#!/usr/bin/python

import json

def Loading (path):
	"""This function Load the file 'path' as a JSON.
	
	Return the parsed structure if success.

	Raise an exception if an error appened.
	"""
	#TODO: raise a custom exception (not ValueError ...)
	try:
		F = open(path,"r")
	except IOError as err:
		print "Loading exception raise :", err
		raise ValueError("")
	file_str = F.read()
	try:
		json_struct = json.loads(file_str)
	except ValueError as err:
		print "Parsing exception raise :", err
		raise ValueError("")
	return json_struct



if __name__ == "__main__":
	print "\nunknown name test :"
	try:
		Loading("unknown name")
	except ValueError:
		print "success"
	else:
		print "error"

	print "\ndirectory test :"
	try:
		Loading("tests/directory")
	except ValueError:
		print "success"
	else:
		print "error"

	print "\nno readable test :"
	try:
		Loading("tests/no_readable")
	except ValueError:
		print "success"
	else:
		print "error"

	print "\nbinary test :"
	try:
		Loading("tests/binary")
	except ValueError:
		print "success"
	else:
		print "error"

	print "\nerror json test :"
	try:
		Loading("tests/error_json")
	except ValueError:
		print "success"
	else:
		print "error"

	print "\ngood test :"
	try:
		Loading("tests/good")
	except ValueError:
		print "error"
	else:
		print "success"

	#TODO: check if all values are present in the JSON and in the good scope(ex: 0 < json_struct["bot"]["x_pos"] <= x_max)